package com.selvin.voicecontrol

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService

class WakeService : Service() {
    // Vosk's small model knows "kelvin" but probably not "selvin".
    // "hey kelvin" sounds the same, so say "Hey Selvin" as normal.
    private val wakePhrase = "hey kelvin"
    private var model: Model? = null
    private var speech: SpeechService? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val channelId = "vc_wake"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Voice listening", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("VoiceControl is listening")
            .setContentText("Say Hey Selvin")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, notification)
        }

        StorageService.unpack(this, "model", "model",
            { m -> model = m; startWakeListening() },
            { _ -> Speaker.say(applicationContext, "Wake word failed to load") }
        )
        return START_STICKY
    }

    private fun startWakeListening() {
        val m = model ?: return
        try {
            val rec = Recognizer(m, 16000.0f, "[\"$wakePhrase\", \"[unk]\"]")
            speech = SpeechService(rec, 16000.0f)
            speech?.startListening(object : RecognitionListener {
                override fun onPartialResult(h: String?) { onHeard(h) }
                override fun onResult(h: String?) { onHeard(h) }
                override fun onFinalResult(h: String?) {}
                override fun onError(e: Exception?) {}
                override fun onTimeout() {}
            })
        } catch (e: Exception) {
            Speaker.say(applicationContext, "Wake word failed to start")
        }
    }

    private fun onHeard(h: String?) {
        if (speech == null || h == null || !h.contains(wakePhrase)) return
        speech?.stop()
        speech?.shutdown()
        speech = null
        Speaker.say(applicationContext, "Yes?")
        handler.postDelayed({ CommandListener.start(applicationContext) }, 1200)
        handler.postDelayed({ startWakeListening() }, 9000)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        speech?.stop()
        speech?.shutdown()
        model?.close()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
