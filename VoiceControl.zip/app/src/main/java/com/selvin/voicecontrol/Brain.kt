package com.selvin.voicecontrol

import android.content.Context
import android.content.Intent
import android.provider.Settings

object Brain {
    fun handle(ctx: Context, raw: String) {
        val text = raw.lowercase().trim()
        when {
            text.startsWith("open ") -> openApp(ctx, text.removePrefix("open "))
            text.contains("wi-fi") || text.contains("wifi") ->
                openSettings(ctx, Settings.ACTION_WIFI_SETTINGS, "Wi-Fi settings")
            text.contains("bluetooth") ->
                openSettings(ctx, Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth settings")
            text.contains("brightness") || text.contains("display") ->
                openSettings(ctx, Settings.ACTION_DISPLAY_SETTINGS, "Display settings")
            text.contains("sound settings") ->
                openSettings(ctx, Settings.ACTION_SOUND_SETTINGS, "Sound settings")
            text == "settings" || text.contains("open settings") ->
                openSettings(ctx, Settings.ACTION_SETTINGS, "Settings")
            text.contains("quick settings") -> {
                HandsService.quickSettings(); Speaker.say(ctx, "Quick settings") }
            text.contains("notifications") -> {
                HandsService.notifications(); Speaker.say(ctx, "Notifications") }
            text.contains("recent apps") || text.contains("recents") -> {
                HandsService.recents(); Speaker.say(ctx, "Recent apps") }
            text.contains("scroll down") -> HandsService.scrollDown()
            text.contains("scroll up") -> HandsService.scrollUp()
            text.contains("go back") || text == "back" -> HandsService.back()
            text.contains("go home") || text == "home" -> HandsService.home()
            text.startsWith("tap ") || text.startsWith("click ") -> {
                val target = text.substringAfter(" ")
                if (HandsService.tapByText(target)) Speaker.say(ctx, "Tapped $target")
                else Speaker.say(ctx, "I could not find $target")
            }
            text.startsWith("type ") -> {
                if (!HandsService.typeText(raw.trim().substringAfter(" ")))
                    Speaker.say(ctx, "No text box is selected")
            }
            else -> Speaker.say(ctx, "Sorry, I did not understand $text")
        }
    }

    private fun openSettings(ctx: Context, action: String, spoken: String) {
        val i = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        Speaker.say(ctx, "Opening $spoken")
    }

    private fun openApp(ctx: Context, name: String) {
        val pm = ctx.packageManager
        val launchIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launchIntent, 0)
        val match = apps.firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(name.trim())
        }
        if (match != null) {
            val i = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
                Speaker.say(ctx, "Opening ${match.loadLabel(pm)}")
                return
            }
        }
        Speaker.say(ctx, "I could not find an app called $name")
    }
}
