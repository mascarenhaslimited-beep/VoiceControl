package com.selvin.voicecontrol

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false

    fun init(ctx: Context) {
        if (tts != null) return
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.UK
                ready = true
            }
        }
    }

    fun say(ctx: Context, text: String) {
        init(ctx)
        if (ready) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "vc")
    }
}
