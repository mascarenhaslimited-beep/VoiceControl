package com.selvin.voicecontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class HandsService : AccessibilityService() {

    companion object {
        var instance: HandsService? = null
        fun back() { instance?.performGlobalAction(GLOBAL_ACTION_BACK) }
        fun home() { instance?.performGlobalAction(GLOBAL_ACTION_HOME) }
        fun recents() { instance?.performGlobalAction(GLOBAL_ACTION_RECENTS) }
        fun notifications() { instance?.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) }
        fun quickSettings() { instance?.performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS) }
        fun scrollDown() { instance?.swipe(540f, 1800f, 540f, 600f) }
        fun scrollUp() { instance?.swipe(540f, 600f, 540f, 1800f) }
        fun tapByText(t: String): Boolean = instance?.clickNodeWithText(t) ?: false
        fun typeText(t: String): Boolean = instance?.setFocusedText(t) ?: false
        fun isReady() = instance != null
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }

    private fun clickNodeWithText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val matches = root.findAccessibilityNodeInfosByText(t)
        for (n in matches) {
            var node: AccessibilityNodeInfo? = n
            while (node != null && !node.isClickable) node = node.parent
            if (node != null) {
                node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                return true
            }
        }
        return false
    }

    private fun setFocusedText(t: String): Boolean {
        val node = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                t
            )
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 300))
            .build()
        dispatchGesture(g, null, null)
    }
}
